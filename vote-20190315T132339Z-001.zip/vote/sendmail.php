

<?php
$con=new mysqli('localhost','root','','voting');


if (!$con)

  {

  die('Could not connect: ' . mysqli_error());

  }
  else
  {
	  echo "kishore";
  }
  if ( $con ) {


if(isset($_GET['emailid']))
{	
	 $emailid = $_GET['emailid']; 
	 echo $emailid;
}

  $res="INSERT INTO mailer(emailid) values ('$emailid')";
  if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
  // $result= mysqli_query($con,$res); 
  
 
 
  
  include 'test.php';
  // $row = mysqli_fetch_assoc($result); 
     // $email="{$row['mailid']}";
	 // echo $email;
//$to_mail="$email";
//$mail_content="$sub";
//$mail_subject="$message";
// send_mqil_using_php_mailer($to_mail,$mail_content,$mail_subject);
$to_mail=$emailid;
$mail_content="http://localhost/vote/keygenerator.html";
$mail_subject=" vote verification";
send_mqil_using_php_mailer($to_mail,$mail_content,$mail_subject)
  }
;
//include 'mailsuccess.html';
//echo "mail sent successfully"
 
// Close connection
mysqli_close($con);
?>
