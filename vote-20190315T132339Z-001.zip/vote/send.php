<?php
try
{
$con=new mysqli('localhost','root','','voting');


if (!$con)

  {

  die('Could not connect: ' . mysqli_error());

  }
  else
  {
	  echo "kishore";
  }
  if ( $con ) {


if(isset($_GET['emailid']))
{	
	 $mailid = $_GET['emailid']; 
	 echo $mailid;
}

  $res="INSERT INTO mailer(emailid) values ('$mailid')";
 if(mysqli_query($con, $res)){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
  }
   include 'test.php';
$to_mail="kkishorekumar8899@gmail.com";
$mail_content="http://localhost/vote/keygenerator.html";
$mail_subject=" vote verification";
send_mqil_using_php_mailer($to_mail,$mail_content,$mail_subject)

;
mysqli_close($con);
}
catch(Exception $e) {
  echo 'Message: ' .$e->getMessage();
}
?>
