<?php
session_start();
if(!isset($_POST["username"]))
{echo "<script>window.location.href='index.html';</script>";}

$con=mysqli_connect("localhost","root","","voting");
$x=$_POST["username"];
$y=$_POST["password"];
$smt=$con->prepare("select * from login where name=? and password=?");
$smt->bind_param('ss',$x,$y);
$smt->execute();
$rst=$smt->get_result();
if($rst->fetch_assoc())
{
	//$_SESSION['uname']=$x;
	include 'dashboard.html';
}
/*else{
	echo '<script>alert("Invalid credentials");</script>';
	echo "<script>window.location.href='index.html';</script>";
}*/
?>