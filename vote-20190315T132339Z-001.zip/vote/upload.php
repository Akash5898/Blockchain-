<?php
session_start();
if(!isset($_SESSION['uname']))
{
echo "<script>window.location.href='index.php';</script>";
}
$con=mysqli_connect("localhost","root","","vote");
$res=$con->query("select * from image");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>upload</title>
</head>
<body>
<form action="upload.php" method="post" enctype="multipart/form-data">
<input type="file" name="file_img" />
<input type="submit" name="btn_upload" value="upload">
</form>
<?php
if(isset($POST['btn_upload']))
{
	//$filetmp = $_FILES["file_img]["name"];
	$filename = $_FILES["file_img]["name"];
	$filetype = $_FILES["file_img]["type"];
	$filepath = "photo/".$filename;
	move_uploaded_file($filetmp,$filepath);
	$sql ="INSERT INTO upload_img (img_name,img_path,imgtype)VALUES('$filename','$filepath','$filetype')";
	$result = mysql_query($sql);
}
?>

	