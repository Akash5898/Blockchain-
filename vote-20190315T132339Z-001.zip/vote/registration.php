<?php
$con=new mysqli('localhost','root','','voting');


if (!$con)

  {

  die('Could not connect: ' . mysqli_error());

  }
 
//if(!empty($first_name))
//{
 
$sql = "INSERT INTO register(firstname,lastname,aadhar,dob,email,mobile,gender,address,city,pincode,state,country,district,constituency) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
//}
 
if($stmt = mysqli_prepare($con, $sql)){
    // Bind variables to the prepared statement as parameters
    mysqli_stmt_bind_param($stmt, "ssisssssssssss", $name1,$name2,$aadhar,$birthday,$birthday2,$birthyear,$email,$mobile,$gender,$address,$city,$pincode,$state,$country);
    
    // Set parameters
	
	if(isset($_GET['name1']))
	{ $first_name = $_GET['name1']; }
	if(isset($_GET['name2']))
	{ $fname = $_GET['name2']; }
    if(isset($_GET['aadhar']))
	{ $iid = $_GET['aadhar']; }
       if(isset($_GET['birthday']))
	{ $dob = $_GET['birthday']; }
 if(isset($_GET['birthday2']))
	{ $schooling = $_GET['birthday2']; }
 if(isset($_GET['birthyear']))
	{ $boardingpt = $_GET['birthyear']; }
 if(isset($_GET['email']))
	{ $bus = $_GET['email']; }
if(isset($_GET['mobile']))
	{ $address = $_GET['mobile']; }
if(isset($_GET['gender']))
	{ $aadhar = $_GET['gender']; }
if(isset($_GET['address']))
	{ $aadhar = $_GET['address']; }
if(isset($_GET['city']))
	{ $aadhar = $_GET['city']; }
if(isset($_GET['pincode']))
	{ $aadhar = $_GET['pincode']; }
if(isset($_GET['state']))
	{ $aadhar = $_GET['state']; }
if(isset($_GET['country']))
	{ $aadhar = $_GET['country']; }
 
   
  //  echo $first_name ;
//	echo $iid;
    // Attempt to execute the prepared statement
    if(mysqli_stmt_execute($stmt)){
        echo "Records inserted successfully.";
    include 'login.html';
    } else{
        echo "ERROR: Could not execute query: $sql. " . mysqli_error($con);
    }
} else{
    echo "ERROR: Could not prepare query: $sql. " . mysqli_error($con);
}
 
// Close statement
mysqli_stmt_close($stmt);
 
// Close connection
mysqli_close($con);
?>